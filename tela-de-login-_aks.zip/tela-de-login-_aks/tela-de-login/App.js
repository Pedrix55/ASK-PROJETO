import React, { useState } from 'react';
import { Button, Text, TextInput, StyleSheet, View } from 'react-native';

const App = () => {
  return (
    <View style={{ flex: 1, backgroundColor: 'grey' }}>
      <TextInput
        style={{
          borderWidth: 1.2,
          backgroundColor: 'white',
          flexDirection: 'row',
          borderRadius: 600 / 2
        }}
        placeholder="Coloque seu Email"
      />
      <TextInput
        style={{ borderWidth: 1.2, backgroundColor: 'white' }}
        placeholder="Coloque sua senha"
      />

      <Button title="Sing in" />

      <Text>Esqueceu a senha?</Text>
    </View>
  );
};

export default App;
