import React, {useState} from 'react'
import {View, Button} from 'react-native';

const Inicial = () => {
  return (
  <View >
  <Button title='Jogar'/>
  </View>
)};

export default Inicial;